#include <iostream>

using namespace std;

struct ciclista{
    int horas;
    int minutos;
    int segundos;
};

int main(){
    int N;
    cout<<"Ingrese el numero de vueltas"<<endl;
    cin>>N;
    struct ciclista C;
    C.horas = C.minutos = C.segundos = 0;
    for(int i = 0; i < N; i++){
        int horas, minutos, segundos;
        cout<<"Ingrese el tiempo en horas, minutos y segundos para la vuelta "<<i + 1<<endl;
        cin>>horas>>minutos>>segundos;
        C.segundos = C.segundos + segundos;
        C.minutos = C.minutos + minutos;
        C.horas = C.horas + horas;
    }
    int mE;
    int hE;
    if (C.segundos > 60){
        mE = C.segundos / 60;
        C.segundos = C.segundos % 60;
        C.minutos = C.minutos + mE;
    }
    if (C.minutos > 60){
        hE = C.minutos / 60;
        C.minutos = C.minutos % 60;
        C.horas = C.horas + hE;
    }
    cout<<"El tiempo total del ciclista fue: "<<C.horas<<":"<<C.minutos<<":"<<C.segundos<<endl;
    cin.get();
    return 0;
}