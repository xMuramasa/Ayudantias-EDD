int main(){
    int N;
    cout<<"Ingrese un numero N de motos"<<endl;
    cin>>N;
    struct moto Arreglo[N];
    for(int i = 0; i < N; i++){
        cout<<"Ingrese el kilometraje de la moto "<<i + 1<<endl;
        cin>>Arreglo[i].kilometraje;
        cout<<"Ingrese el estado de la rueda 1 y 2 "<<endl;
        cin>>Arreglo[i].rueda1>>Arreglo[i].rueda2;
    }
    int total = 0;
    for(int i = 0; i < N; i++){
        total = total + foo(Arreglo[i]);
    }
    cout<<"El total a cobrar es "<<total<<" pesos chilenos."<<endl;
    cin.get();
    return 0;
}