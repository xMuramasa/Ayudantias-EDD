#include <iostream>
using namespace std;

#define UF 29415

struct moto{
    int rueda1;
    int rueda2;
    int kilometraje;
};

int foo(struct moto &A){
    int cont = 0;
    if(!A.rueda1){
        cout<<"La rueda 1 esta pinchada"<<endl;
        cont++;
        A.rueda1 = 1;
    }
    if(!A.rueda2){
        cout<<"La rueda 2 esta pinchada"<<endl;
        cont++;
        A.rueda2 = 1;
    }
    cout<<"La Moto tenia "<<cont<<" rueda/s pinchadas"<<endl;
    if(cont > 0){
        if(A.kilometraje >= 20000){
            return cont*5*UF;
        }
        else if(A.kilometraje >= 50000){
            return cont*10*UF;
        }
        else{
            return UF;
        }
    }
    return 0;
}