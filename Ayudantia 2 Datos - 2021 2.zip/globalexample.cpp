#include <iostream>

using namespace std;

int x = 10;

void alCuadrado(int& a){
    a = a * a;
    x++;
}

int main(){
    cout << "x = " << x << endl; // x = 10
    alCuadrado(x);
    cout << "x = " << x << endl; // x = 101
    return 0;
}