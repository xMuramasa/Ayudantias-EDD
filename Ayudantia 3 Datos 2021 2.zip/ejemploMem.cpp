// Programa que almacena el puntaje PDT de un numero n de estudiantes en un arreglo dinamico

#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Ingrese numero total de  estudiantes: ";
    cin >> num;
    float* ptr;
    
    //asignación de la memoria del arreglo de tipo float de tamagno num
    ptr = new float[num];

    cout << "Ingrese puntaje PDT de los estudiantes." << endl;
    for (int i = 0; i < num; ++i) {
        cout << "Estudiante " << i + 1 << ": ";
        cin >> *(ptr + i);
    }

    cout << "\nMostrando puntajes PDT de los estudiantes." << endl;
    for (int i = 0; i < num; ++i) {
        cout << "Estudiante " << i + 1 << " :" << *(ptr + i) << endl;
    }

    // memoria de ptr es liberada
    delete[] ptr;

    return 0;
}