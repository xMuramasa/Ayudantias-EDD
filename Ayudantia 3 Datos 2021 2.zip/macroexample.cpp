#include <iostream>

using namespace std;

#define N 100

int main(){
    int a = N;
    // Reemplaza el N por un 100 (int a = 100;)
    int b[N];
    // Reemplaza el N por un 100 (int b[100];)
    int N = 0;
    // Esta asignacion genera ERROR, ya que realiza el cambio N por un 100
    // int 100 = 0; 
    return 0;
}